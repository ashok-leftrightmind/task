import { TaskElements } from './../app.component';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TaskDataService } from '../task-data.service';

@Component({
  selector: 'app-addcomment',
  templateUrl: './addcomment.component.html',
  styleUrls: ['./addcomment.component.css'],
})
export class AddcommentComponent implements OnInit {
  commentData;
  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<AddcommentComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private taskService: TaskDataService
  ) {

    this.commentData = this.fb.group({
      comment: [''],
    });
  }

  ngOnInit(): void {}

  onClose(): void {
    this.dialogRef.close();
  }

  onComment(){
    let addComment: TaskElements = {
      label: this.data.label,
      mark: this.data.mark,
      comment:''
    };
    if (this.commentData.status === 'VALID') {
      addComment.comment = this.commentData.value.comment;
      let index = this.taskService.getIndex(this.data);
      this.taskService.updateTask(index, addComment);
      this.taskService.usersDataChange(addComment.comment);
    }
    this.commentData.reset();
    this.onClose();
  }
}
