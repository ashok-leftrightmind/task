import { AddcommentComponent } from './addcomment/addcomment.component';
import { UpdateTaskComponent } from './update-task/update-task.component';
import { TaskDataService } from './task-data.service';
import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
export interface TaskElements {
  label: string;
  mark: boolean;
  comment:string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'todo-list';
  checked: boolean;
  task;
  displayedColumns: string[] = ['Task', 'markAsDone', 'edit', 'delete','addComment'];
  dataSource;
  constructor(
    private fb: FormBuilder,
    public taskService: TaskDataService,
    public dialog: MatDialog
  ) {
    this.taskService.userNotifyMessage.subscribe(() => {
      this.dataSource = this.taskService.getAllTask();
    });
    this.task = this.fb.group({
      label: [''],
    });
  }

  onSubmit() {
    let task: TaskElements = {
      label: '',
      mark: false,
      comment:''
    };
    if (this.task.status === 'VALID') {
      task.label = this.task.value.label;
      this.taskService.addtask(task);
      this.dataSource = [...this.taskService.getAllTask()];
    }
    this.task.reset();
  }

  onUpdateTask(element) {
    this.dialog.open(UpdateTaskComponent, { width: '500px', data: element });
    console.log(element);
  }
  onDeleteTask(element) {
    this.taskService.deleteTask(element);
    this.dataSource = [...this.taskService.getAllTask()];
    console.log(element);
  }

  onCheck(element) {
    let newElement = { ...element };
    let index = this.taskService.getIndex(newElement);
    newElement.mark = element.mark ? false : true;
    this.taskService.updateTask(index, newElement);
    this.dataSource = [...this.taskService.getAllTask()];
    // console.log(element);
  }

  addComment(element){
    this.dialog.open(AddcommentComponent, { width: '500px', data: element });
  }
}
