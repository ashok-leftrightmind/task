import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { TaskElements } from './app.component';

@Injectable({
  providedIn: 'root',
})
export class TaskDataService {
  public userNotify = new Subject<string>();
  public userNotifyMessage = this.userNotify.asObservable();
  totalTasks: TaskElements[] = [];
  constructor() {
    // this.totalTasks.push({ label: 'Sneha', mark: true });
  }
  usersDataChange(observer: string) {
    this.userNotify.next(observer);
  }
  addtask(task: TaskElements) {
    // console.log(this.totalTasks);

    this.totalTasks.push(task);
    return true;
  }

  updateTask(index, task: TaskElements) {
    this.totalTasks[index] = task;
    // console.log(this.totalTasks);

    return true;
  }

  deleteTask(element: TaskElements) {
    let index = this.totalTasks.indexOf(element);
    if (index > -1) {
      this.totalTasks.splice(index, 1);
    }
    return true;
  }

  getTask(index: number): TaskElements {
    return this.totalTasks[index];
  }

  getAllTask(): TaskElements[] {
    // console.log(this.totalTasks);
    return this.totalTasks;
  }
  getIndex(task: TaskElements) {
    let indexValue;
    this.totalTasks.findIndex((data, index) => {
      if (data.label === task.label) {
        indexValue = index;
        return;
      }
    });
    // console.log(indexValue);
    return indexValue;
  }
}
