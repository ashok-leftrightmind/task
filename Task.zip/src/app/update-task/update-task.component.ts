import { TaskDataService } from './../task-data.service';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TaskElements } from '../app.component';

@Component({
  selector: 'app-update-task',
  templateUrl: './update-task.component.html',
  styleUrls: ['./update-task.component.css'],
})
export class UpdateTaskComponent implements OnInit {
  updateTask;
  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<UpdateTaskComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private taskService: TaskDataService
  ) {
    this.updateTask = this.fb.group({
      label: [this.data.lable],
    });
  }

  ngOnInit(): void {}

  onUpdate() {
    let updateTask: TaskElements = {
      label: '',
      mark: false,
    };
    if (this.updateTask.status === 'VALID') {
      updateTask.label = this.updateTask.value.label;
      let index = this.taskService.getIndex(this.data);
      this.taskService.updateTask(index, updateTask);
      this.taskService.usersDataChange('update');
    }
    this.updateTask.reset();
    this.onClose();
  }

  onClose(): void {
    this.dialogRef.close();
  }
}
